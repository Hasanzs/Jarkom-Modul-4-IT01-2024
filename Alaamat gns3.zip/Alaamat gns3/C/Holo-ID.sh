auto eth0
iface eth0 inet static
	address 10.81.64.1
	netmask 255.255.128.0
#	gateway 192.168.0.1
	up echo nameserver 192.168.122.1 > /etc/resolv.conf

# DHCP config for eth0
#auto eth0
#iface eth0 inet dhcp
#	hostname kuuhakugns3-32

# Static config for eth1
auto eth1
iface eth1 inet static
	address 10.81.4.1
	netmask 255.255.248.0
	up echo nameserver 192.168.122.1 > /etc/resolv.conf

auto eth2
iface eth2 inet static
	address 10.81.0.64
	netmask 255.255.255.128
	up echo nameserver 192.168.122.1 > /etc/resolv.conf

auto eth3
iface eth3 inet static
	address 10.81.128.2
	netmask 255.255.255.252
	gateway 10.81.128.1
	up echo nameserver 192.168.122.1 > /etc/resolv.conf

route add -net 10.81.0.0 netmask 255.255.255.252 gw 10.81.0.5
route add -net 10.81.0.4 netmask 255.255.255.252 gw 10.81.0.5
route add -net 10.81.0.128 netmask 255.255.255.252 gw 10.81.4.2
route add -net 10.81.8.0 netmask 255.255.255.252 gw 10.81.64.2
route add -net 10.81.8.4 netmask 255.255.255.252 gw 10.81.64.2