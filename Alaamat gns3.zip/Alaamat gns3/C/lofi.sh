auto eth0
iface eth0 inet static
	address 10.81.8.7
	netmask 255.255.255.0
	gateway 10.81.8.4
	up echo nameserver 192.168.122.1 > /etc/resolv.conf