auto eth0
iface eth0 inet static
	address 10.81.0.130
	netmask 255.255.255.128
	gateway 10.81.0.128
	up echo nameserver 192.168.122.1 > /etc/resolv.conf