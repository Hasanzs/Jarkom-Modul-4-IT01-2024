auto eth0
iface eth0 inet static
	address 10.81.8.4
	netmask 255.255.192.0
	up echo nameserver 192.168.0.1 > /etc/resolv.conf

auto eth1
iface eth1 inet static
	address 10.81.64.2
	netmask 255.255.255.252
	gateway 10.81.64.1
	up echo nameserver 192.168.122.1 > /etc/resolv.conf

route add -net 10.81.0.0 netmask 255.255.255.252 gw 10.81.64.1
route add -net 10.81.0.4 netmask 255.255.255.252 gw 10.81.64.1
route add -net 10.81.0.64 netmask 255.255.255.252 gw 10.81.64.1
route add -net 10.81.0.128 netmask 255.255.255.252 gw 10.81.64.1
route add -net 10.81.4.0 netmask 255.255.255.252 gw 10.81.64.1