auto eth0
iface eth0 inet static
	address 10.81.0.4
	netmask 255.255.255.192
	up echo nameserver 192.168.122.1 > /etc/resolv.conf

auto eth1
iface eth1 inet static
	address 10.81.0.65
	netmask 255.255.255.252
	gateway 10.81.0.64
	up echo nameserver 192.168.122.1 > /etc/resolv.conf