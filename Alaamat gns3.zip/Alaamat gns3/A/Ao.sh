auto eth0
iface eth0 inet static
	address 10.64.128.6
	netmask 255.255.255.248
	gateway 10.64.128.4
	up echo nameserver 192.168.122.1 > /etc/resolv.conf