auto eth0
iface eth0 inet static
	address 10.64.0.6
	netmask 255.255.255.224
	gateway 10.64.0.4
	up echo nameserver 192.168.122.1 > /etc/resolv.conf

route add -net 10.64.0.0 netmask 255.255.255.252 gw 10.64.0.4
route add -net 10.64.0.4 netmask 255.255.255.252 gw 10.64.0.4
