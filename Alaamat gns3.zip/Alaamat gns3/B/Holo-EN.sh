auto eth0
iface eth0 inet static
	address 10.80.4.1
	netmask 255.255.255.0
	up echo nameserver 192.168.122.1 > /etc/resolv.conf

auto eth1
iface eth1 inet static
	address 10.80.64.1
	netmask 255.255.255.252
	up echo nameserver 192.168.122.1 > /etc/resolv.conf

auto eth2
iface eth2 inet static
	address 10.80.128.2
	netmask 255.255.255.252
	gateway 10.80.128.1
	up echo nameserver 192.168.122.1 > /etc/resolv.conf

route add -net 10.80.0.0 netmask 255.255.255.252 gw 10.80.4.2
route add -net 10.80.0.8 netmask 255.255.255.252 gw 10.80.4.2
route add -net 10.80.0.128 netmask 255.255.255.252 gw 10.80.4.2
route add -net 10.80.1.0 netmask 255.255.255.252 gw 10.80.4.2
route add -net 10.80.8.0 netmask 255.255.255.252 gw 10.80.64.2
route add -net 10.80.8.4 netmask 255.255.255.252 gw 10.80.64.2