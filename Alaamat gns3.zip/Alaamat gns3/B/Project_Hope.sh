auto eth0
iface eth0 inet static
	address 10.80.0.1
	netmask 255.255.255.252
	up echo nameserver 192.168.122.1 > /etc/resolv.conf

auto eth1
iface eth1 inet static
	address 10.80.0.130
	netmask 255.255.255.252
	gateway 10.80.0.128
	up echo nameserver 192.168.122.1 > /etc/resolv.conf