auto eth0
iface eth0 inet static
	address 10.80.0.9
	netmask 255.255.255.224
	gateway 10.80.0.8
	up echo nameserver 192.168.122.1 > /etc/resolv.conf