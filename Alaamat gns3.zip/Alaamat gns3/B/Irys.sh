auto eth0
iface eth0 inet static
	address 10.80.0.2
	netmask 255.255.255.252
	gateway 10.80.0.1
	up echo nameserver 192.168.122.1 > /etc/resolv.conf