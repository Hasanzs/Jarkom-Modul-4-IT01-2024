auto eth0
iface eth0 inet static
	address 10.80.0.8
	netmask 255.255.255.128
#	gateway 10.68.0.8
	up echo nameserver 192.168.122.1 > /etc/resolv.conf

# DHCP config for eth0
#auto eth0
#iface eth0 inet dhcp
#	hostname kuuhakugns3-23

# Static config for eth1
auto eth1
iface eth1 inet static
	address 10.80.0.129
	netmask 255.255.255.252
	gateway 10.80.0.128
	up echo nameserver 192.168.122.1 > /etc/resolv.conf