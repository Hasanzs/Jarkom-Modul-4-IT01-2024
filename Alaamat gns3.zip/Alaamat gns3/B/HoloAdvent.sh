auto eth0
iface eth0 inet static
	address 10.80.8.4
	netmask 255.255.128.0
	up echo nameserver 192.168.122.1 > /etc/resolv.conf

auto eth1
iface eth1 inet static
	address 10.80.64.2
	netmask 255.255.255.252
	gateway 10.80.64.1
	up echo nameserver 192.168.122.1 > /etc/resolv.conf

route add -net 10.80.0.4 netmask 255.255.255.252 gw 10.80.64.1
route add -net 10.80.0.8 netmask 255.255.255.252 gw 10.80.64.1
route add -net 10.80.0.128 netmask 255.255.255.252 gw 10.80.64.1
route add -net 10.80.1.0 netmask 255.255.255.252 gw 10.80.64.1
route add -net 10.80.4.0 netmask 255.255.255.252 gw 10.80.64.1